<?php
require 'config.php';

$id = intval($_POST['id']);
$nombre = $conn->real_escape_string($_POST['nombre']);
$keyword_google = $conn->real_escape_string($_POST['keyword_google']);
$busqueda = intval($_POST['busqueda']);

$sql = "UPDATE ll_rubros SET nombre = '$nombre', keyword_google = '$keyword_google', busqueda = $busqueda WHERE id = $id";

if ($conn->query($sql) === TRUE) {
    echo "Rubro actualizado correctamente.";
} else {
    echo "Error: " . $conn->error;
}

$conn->close();
?>